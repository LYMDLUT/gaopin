*****************************************************************
Agilent 33220A Arbitrary function generator Control MATLAB APP
*****************************************************************
.. contents:: Table of Contents
   :depth: 2

Introduction 
=======================
For controlling 

.. image:: https://github.com/bwang40/Agilent33220A_MatlabVisa/blob/master/image/scrshot.PNG
   :scale: 25
   
Manual
==============

