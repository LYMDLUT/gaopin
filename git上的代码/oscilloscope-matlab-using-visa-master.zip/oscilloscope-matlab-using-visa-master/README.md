# oscilloscope-matlab-using-visa
Useful links:
1. https://www.mathworks.com/matlabcentral/fileexchange/28887-capturing-a-waveform-from-an-agilent-oscilloscope-over-a-standard-visa-interface
2. 
