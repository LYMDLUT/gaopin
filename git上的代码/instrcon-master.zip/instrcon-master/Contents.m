% INSTRCON      A package providing instrument control for scientific measurements
%
% Please visit <a href="matlab: 
% web('http://www.github.com/danieljackcox/instrcon')">instrcon github</a>
% for the most up-to-date version and for extra documentation
